import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { Checkbox } from 'react-native-paper';

export default function CalculateFeesScreen({ navigation }) {

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [selectedCourses, setSelectedCourses] = useState([]);
  const [totalFee, setTotalFee] = useState(null);

  const courses = [
    { name: 'First Aid', price: 1500 },
    { name: 'Sewing', price: 1500 },
    { name: 'Landscaping', price: 1500 },
    { name: 'Life Skills', price: 1500 },
    { name: 'Child Minding', price: 750 },
    { name: 'Cooking', price: 750 },
    { name: 'Garden Maintenance', price: 750 },
  ];

  const toggleCourseSelection = (courseName) => {
    setSelectedCourses((prevSelectedCourses) => {
      if (prevSelectedCourses.includes(courseName)) {
        return prevSelectedCourses.filter(course => course !== courseName);
      } else {
        return [...prevSelectedCourses, courseName];
      }
    });
  };

  const validateForm = () => {
    if (!name || !phone || !email) {
      Alert.alert('Error', 'Please fill in all the details.', [{ text: 'OK' }]);
      return false;
    }
    return true;
  };

  const calculateFees = () => {
    if (!validateForm()) return;

    let total = 0;
    selectedCourses.forEach((courseName) => {
      const course = courses.find(course => course.name === courseName);
      if (course) total += course.price;
    });

    let discount = 0;
    if (selectedCourses.length === 2) discount = 0.05;
    if (selectedCourses.length === 3) discount = 0.10;
    if (selectedCourses.length > 3) discount = 0.15;

    const discountAmount = total * discount;
    const totalAfterDiscount = total - discountAmount;
    const vat = totalAfterDiscount * 0.15; 
    const finalTotal = totalAfterDiscount + vat;

    setTotalFee({
      total,
      discount: discountAmount,
      vat,
      finalTotal
    });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerText}>Calculate Fees</Text>

      <View style={styles.infoBox}>
        <TextInput
          style={styles.input}
          placeholder="Your Name"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
        />
        <TextInput
          style={styles.input}
          placeholder="Email Address"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
      </View>

      <Text style={styles.subheading}>Select Courses</Text>
      {courses.map(course => (
        <View key={course.name} style={styles.checkboxContainer}>
          <Checkbox
            status={selectedCourses.includes(course.name) ? 'checked' : 'unchecked'}
            onPress={() => toggleCourseSelection(course.name)}
          />
          <Text style={styles.checkboxText}>{course.name} - R{course.price}</Text>
        </View>
      ))}

      <TouchableOpacity style={styles.calculateButton} onPress={calculateFees}>
        <Text style={styles.buttonText}>Calculate Fees</Text>
      </TouchableOpacity>

      {totalFee && (
        <View style={styles.feeContainer}>
          <Text style={styles.feeText}>Fee Breakdown</Text>
          <Text style={styles.feeText}>Normal Total: R{totalFee.total}</Text>
          <Text style={styles.feeText}>Discount: -R{totalFee.discount}</Text>
          <Text style={styles.feeText}>VAT (15%): R{totalFee.vat}</Text>
          <Text style={styles.feeText}>Total: R{totalFee.finalTotal}</Text>
        </View>
      )}

      <TouchableOpacity
        style={styles.checkoutButton}
        onPress={() => navigation.navigate('ContactDetails')}
      >
        <Text style={styles.buttonText}>Proceed to Checkout</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.navigate('Home')}
      >
        <Text style={styles.buttonText}>Back to Home</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ADD8E6',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    backgroundColor: '#FFD700',  
    padding: 10,
  },
  infoBox: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 15,
    fontSize: 16,
  },
  subheading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    marginTop: 20,
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  checkboxText: {
    fontSize: 16,
  },
  calculateButton: {
    backgroundColor: '#800080', 
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  feeContainer: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
  },
  feeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  checkoutButton: {
    backgroundColor: '#32CD32', 
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: '#808080', 
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
});






