import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import RNPickerSelect from 'react-native-picker-select';

export default function ContactDetailsScreen({ navigation }) {
  const [selectedAddress, setSelectedAddress] = useState(null);

  const addresses = [
    {
      label: 'Venue 1: Johannesburg, Rosebank',
      value: 'venue1',
      latitude: -26.1445,
      longitude: 28.0351,
    },
    {
      label: 'Venue 2: Johannesburg, Sandton',
      value: 'venue2',
      latitude: -26.1065,
      longitude: 28.0442,
    },
    {
      label: 'Venue 3: Johannesburg, Midrand',
      value: 'venue3',
      latitude: -25.9991,
      longitude: 28.1248,
    },
  ];

  const phone = '0845329687';
  const email = 'iamg721@gmail.com';

  const handleAddressChange = (value) => {
    setSelectedAddress(value);
  };

  const selectedLocation = addresses.find((address) => address.value === selectedAddress);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerText}>Contact Details</Text>

      <View style={styles.infoBox}>
        <Text style={styles.infoText}>Phone: {phone}</Text>
        <Text style={styles.infoText}>Email: {email}</Text>
      </View>

      <Text style={styles.addressHeader}>Select Address</Text>

      <RNPickerSelect
        onValueChange={handleAddressChange}
        items={addresses.map((address) => ({
          label: address.label,
          value: address.value,
        }))}
        placeholder={{ label: 'Select an address', value: null }}
        style={pickerStyles}
      />


      {selectedLocation && (
        <MapView
          style={styles.map}
          region={{
            latitude: selectedLocation.latitude,
            longitude: selectedLocation.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          }}
        >
          <Marker
            coordinate={{
              latitude: selectedLocation.latitude,
              longitude: selectedLocation.longitude,
            }}
            title="Selected Venue"
            description={selectedLocation.label}
          />
        </MapView>
      )}

      <TouchableOpacity style={styles.backButton} onPress={() => navigation.navigate('Home')}>
        <Text style={styles.buttonText}>Back to Home</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ADD8E6',
  },
  headerText: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
    backgroundColor: '#FFD700',
    padding: 10,
  },
  infoBox: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
  },
  infoText: {
    fontSize: 18,
    marginBottom: 10,
  },
  addressHeader: {
    fontSize: 22,
    fontWeight: 'bold',
    marginVertical: 10,
    backgroundColor: '#FFD700',
    padding: 10,
  },
  map: {
    height: 300,
    marginVertical: 20,
  },
  backButton: {
    backgroundColor: '#808080',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

const pickerStyles = StyleSheet.create({
});


