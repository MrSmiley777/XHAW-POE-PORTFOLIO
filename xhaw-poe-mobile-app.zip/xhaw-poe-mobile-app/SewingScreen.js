import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Image } from 'react-native';

export default function SewingScreen({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerBox}>
        <Text style={styles.headerText}>Sewing</Text>
      </View>
      <Image source={require('./assets/sewing.png')} style={styles.image} />
      <View style={styles.infoBox}>
        <Text style={styles.subheading}>Course Overview</Text>
        <Text style={styles.infoText}>
          To provide alterations and new garment tailoring services.
        </Text>
        <Text style={styles.subheading}>Course Content</Text>
        <Text style={styles.infoText}>
          • Types of stitches{'\n'}
          • Threading a sewing machine{'\n'}
          • Sewing buttons, zips, hems and seams{'\n'}
          • Alterations{'\n'}
          • Designing and sewing new garments
        </Text>
        <Text style={styles.subheading}>Course Fees</Text>
        <Text style={styles.feeText}>R1500</Text>
      </View>
      <TouchableOpacity 
        style={styles.enrollButton}
        onPress={() => navigation.navigate('CalculateFees')}
      >
        <Text style={styles.enrollButtonText}>Enroll Now</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
        <Text style={styles.backButtonText}>Back to Six Month Courses</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ADD8E6',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  headerBox: {
    backgroundColor: '#FFD700',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  image: {
    width: '100%',
    height: 200,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  infoBox: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 20,
  },
  subheading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  infoText: {
    fontSize: 16,
    marginBottom: 15,
    lineHeight: 22,
  },
  feeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000000',
    marginBottom: 20,
  },
  enrollButton: {
    backgroundColor: '#800080',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
  },
  enrollButtonText: {
    color: '#00FFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  backButton: {
    backgroundColor: '#808080',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
