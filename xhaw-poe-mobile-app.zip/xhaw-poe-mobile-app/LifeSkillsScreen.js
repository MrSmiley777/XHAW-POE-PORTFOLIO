import React from 'react';
import { View,Text, Image,TouchableOpacity,StyleSheet,ScrollView} from 'react-native';

export default function LifeSkillsScreen({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerBox}>
        <Text style={styles.headerText}>Life Skills</Text>
      </View>
      <Image
        source={require('./assets/lifeskillsdetailed.png')}
        style={styles.image}
      />
      <View style={styles.contentBox}>
        <Text style={styles.subheading}>Course Overview</Text>
        <Text style={styles.text}>
          To provide skills to navigate basic life necessities.
        </Text>
      </View>
      <View style={styles.contentBox}>
        <Text style={styles.subheading}>Course Content</Text>
        <Text style={styles.text}>
          • Opening a bank account{'\n'}
          • Basic labour law (know your rights){'\n'}
          • Basic reading and writing literacy{'\n'}
          • Basic numeric literacy
        </Text>
      </View>
      <View style={styles.contentBox}>
        <Text style={styles.subheading}>Course Fees</Text>
        <Text style={styles.feeText}>R1500</Text>
      </View>
      <TouchableOpacity 
        style={styles.enrollButton}
        onPress={() => navigation.navigate('CalculateFees')}
      >
        <Text style={styles.enrollButtonText}>Enroll Now</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.navigate('SixMonthCourses')}
      >
        <Text style={styles.backButtonText}>Back to Six Month Courses</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ADD8E6',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  headerBox: {
    backgroundColor: '#FFD700',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  image: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
    borderRadius: 5,
    marginBottom: 20,
  },
  contentBox: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  subheading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  text: {
    fontSize: 16,
    lineHeight: 24,
  },
  feeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  enrollButton: {
    backgroundColor: '#800080',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 20,
  },
  enrollButtonText: {
    color: '#00FFFF',
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#808080',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});
