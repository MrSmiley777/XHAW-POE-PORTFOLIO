import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';

export default function SixWeekCoursesScreen({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerBox}>
        <Text style={styles.headerText}>Six Week Courses</Text>
      </View>
      <View style={styles.courseBox}>
        <Text style={styles.courseTitle}>Child Minding</Text>
        <Text style={styles.courseDescription}>Learn basic child and baby care.</Text>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('ChildMinding')}
        >
          <Text style={styles.buttonText}>Details</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.courseBox}>
        <Text style={styles.courseTitle}>Cooking</Text>
        <Text style={styles.courseDescription}>
          Learn to prepare and cook nutritious family meals.
        </Text>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Cooking')}
        >
          <Text style={styles.buttonText}>Details</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.courseBox}>
        <Text style={styles.courseTitle}>Garden Maintenance</Text>
        <Text style={styles.courseDescription}>
          Learn basic gardening techniques for a domestic garden.
        </Text>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('GardenMaintenance')}
        >
          <Text style={styles.buttonText}>Details</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backButtonText}>Back to Home</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ADD8E6',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  headerBox: {
    backgroundColor: '#FFD700',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  courseBox: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 5,
    marginBottom: 20,
    borderColor: '#ccc',
    borderWidth: 1,
  },
  courseTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  courseDescription: {
    fontSize: 16,
    marginVertical: 10,
  },
  button: {
    backgroundColor: '#800080',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#00FFFF',
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#808080',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 30,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});
